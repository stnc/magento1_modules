<?php
error_reporting(E_ALL | E_STRICT);
/**
 * Mage SMS - SMS notification & SMS marketing
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the BSD 3-Clause License
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/BSD-3-Clause
 *
 * @category    TOPefekt
 * @package     TOPefekt_Magesms
 * @copyright   Copyright (c) 2012-2015 TOPefekt s.r.o. (http://www.mage-sms.com)
 * @license     http://opensource.org/licenses/BSD-3-Clause
 */
class Topefekt_Magesms_Helper_Adminhtml_Data extends Mage_Adminhtml_Helper_Data
{
    public function setPageHelpUrl($url = NULL, $suffix = NULL)
    {
        return $this;
    }

}
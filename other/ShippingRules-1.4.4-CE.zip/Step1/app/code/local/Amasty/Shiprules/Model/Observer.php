<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Shiprules
 */
class Amasty_Shiprules_Model_Observer extends Amasty_Commonrules_Model_Observer
{
    protected $_module = 'amshiprules';

}
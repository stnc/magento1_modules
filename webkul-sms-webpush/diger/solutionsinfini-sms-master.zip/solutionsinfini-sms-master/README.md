# solutionsinfini-sms
Send SMS from magento using solutionsinfini API
